Mario Kart 112 is a game where the player can race for the fastest time on different race tracks. 
On each race track are item boxes that randomly select one out of 4 available items that the player can collect along the way.
The player is also able to customize their character before the match.

Run 'Mario Kart 112.py'. That's the only python file so running the game should be easy enough.

No libararies need to be installed, and shortcuts can be accessed by pressing 'h' for the help menu once the game is running.
